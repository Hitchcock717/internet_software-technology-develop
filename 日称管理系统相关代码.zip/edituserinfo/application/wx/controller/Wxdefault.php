<?php
/**
 * Created by PhpStorm.
 * User: 84333
 * Date: 2019/4/14
 * Time: 9:46
 */

namespace app\wx\controller;


use app\wx\common\Common;
use app\logmanage\model\Log as LogModel;


class Wxdefault extends Common
{

}