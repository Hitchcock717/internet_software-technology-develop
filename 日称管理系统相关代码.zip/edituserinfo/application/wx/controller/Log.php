<?php
/**
 * Created by PhpStorm.
 * User: 84333
 * Date: 2019/4/14
 * Time: 9:48
 */

namespace app\wx\controller;


use app\wx\common\Common;

class Log extends  Common
{

}